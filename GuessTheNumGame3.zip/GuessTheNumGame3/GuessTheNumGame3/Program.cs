﻿using System;

namespace GuessTheNumber
{
    class Program
    {
        //int randNum = 0;
        //int userNum = 0;
        //int gameStatus = 0;

        static void Main(string[] args)
        {

            bool gameStatus = false;

            Random randomNumbers = new Random(); // random-number generator
            var data = new int[1000]; // creates space for the array to store the numbers you guessed 

            int randNum = randomNumbers.Next(1, 1001); // picks a random-number from 1 - 1000

            UserNumber(randNum, gameStatus); // this shoots these paremeters into the userNumber method

            

            // Made by Tamer Ayoub
        }

        static void UserNumber(int randNum, bool gameStatus)
        {
            int yesOrno = 0;

            do
            {
                Console.WriteLine("Please guess a number between 1 and 1000!");
                int userNum = Convert.ToInt32(Console.ReadLine()); // this converts the users input to a integer from a string
               
                GuessLogic(userNum, randNum, gameStatus, yesOrno); // this shoots these paremeters into the GuessLogic method

            }
            while (gameStatus == false); // continue the game if the user didnt enter -1 to quit the game

            
            

        }

        public static void GuessLogic(int userNum, int randNum, bool gameStatus, int yesOrno)
        {

            if (userNum < randNum)
            {
                Console.WriteLine("Incorrect, that number is too low, try again.");
            }

            else if (userNum > randNum)
            {
                Console.WriteLine("Incorrect, that number is too high, try again.");
            }

            else
            {
                Console.WriteLine("Congratulations, you have guessed the correct number! Press enter to go to the back main screen.");
                yesOrno = Convert.ToInt32(Console.ReadLine());

                do
                {

                    if (yesOrno != 1 || yesOrno != 2)
                    {
                        Console.WriteLine("Do you want to play again? Press 1 to continue, or press 2 to quit");
                        yesOrno = Convert.ToInt32(Console.ReadLine());
                    }


                    if (yesOrno == 1)
                    {
                        break;
                    }

                    if (yesOrno == 2)
                    {
                        int exit = 0;
                        System.Environment.Exit(exit);
                    }
                }
                while (yesOrno != 1 || yesOrno != 2);
            }
        }
    }
}

























































































































































